.. -*- coding: utf-8 -*-

.. This file contains all links we use for documentation in a centralized place

.. _idiap: http://www.idiap.ch
.. _bob: http://www.idiap.ch/software/bob
.. _installation: https://www.idiap.ch/software/bob/install
.. _mailing list: https://www.idiap.ch/software/bob/discuss