.. -*- coding: utf-8 -*-

.. _bob.paper.ijcb2021_synthetic_dataset:

=============
 New package
=============

.. todo ::
   Write here a small (1 paragraph) introduction explaining this project. See
   other projects for examples.



Users Guide
===========

.. toctree::
   :maxdepth: 2

   api

.. todolist::

.. include:: links.rst