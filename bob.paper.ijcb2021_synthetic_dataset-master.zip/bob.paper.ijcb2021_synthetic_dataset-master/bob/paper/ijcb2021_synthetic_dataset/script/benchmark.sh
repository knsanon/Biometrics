#!/bin/bash
### Run pipelines (bob bio pipelines)
output_dir=$(bob config get bob.synface.scores.directory)/benchmark
run_pipeline='bob bio pipeline vanilla-biometrics'

declare -A baseline_paths=(
    ["gabor_graph"]="gabor_graph"
    ["lgbphs"]="lgbphs"
    ["arcface"]="arcface-insightface"
    ["inception_resnetv1_casiawebface"]="inception-resnetv1-casiawebface"
    ["inception_resnetv2_casiawebface"]="inception-resnetv2-casiawebface"
    ["resnet50_vgg2_arcface"]="resnet50-vgg2-arcface-2021"
)

databases=(
    multipie
    synmultipie
)

protocols=(
    U
    E
    P
)

baselines=(
    gabor_graph
    lgbphs
    arcface
    inception_resnetv1_casiawebface
    inception_resnetv2_casiawebface  
    resnet50_vgg2_arcface
)

set -x
for database in "${databases[@]}"
do
    for protocol in "${protocols[@]}"
    do
        for baseline in "${baselines[@]}"
        do
            $run_pipeline -vv bob/paper/ijcb2021_synthetic_dataset/config/database/$database/$protocol.py "${baseline_paths[$baseline]}" -m -l sge -g dev -o $output_dir/$database/$protocol/$baseline
        done
    done
done
