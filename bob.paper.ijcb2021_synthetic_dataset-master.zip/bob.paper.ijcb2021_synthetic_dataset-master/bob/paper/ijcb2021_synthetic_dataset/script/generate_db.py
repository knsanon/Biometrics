# Copyright (c) 2021, Idiap Research Institute. All rights reserved.
#
# This work is made available under a custom license, Non-Commercial Research and Educational Use Only 
# To view a copy of this license, visit
# https://gitlab.idiap.ch/bob/bob.paper.ijcb2021_synthetic_dataset/-/blob/master/LICENSE.txt
from bob.extension import rc
from bob.bio.face.preprocessor import FaceCrop
from bob.bio.face_ongoing.configs.baselines.msceleb.inception_resnet_v2.centerloss_rgb import extractor
from ..generate.db_generator import DBGenerator
from ..stylegan2.generator import StyleGAN2Generator
from ..stylegan2.dnnlib import tflib
from ..utils import get_task

import pickle as pkl
from scipy.spatial.distance import cdist
import h5py
import os
import time

import click
from bob.extension.scripts.click_helper import ConfigCommand, ResourceOption


def get_postprocessing_fn():
    SG2_REYE_POS = (480, 380)
    SG2_LEYE_POS = (480, 650)

    SIZE = 182
    cropped_size = (SIZE, SIZE)
    IMG_REYE_POS = (SIZE / 3, SIZE / 3)
    IMG_LEYE_POS = (SIZE / 3, 2 * SIZE / 3)
    postprocessor = FaceCrop(
        cropped_image_size=cropped_size,
        cropped_positions={"reye": IMG_REYE_POS, "leye": IMG_LEYE_POS},
        color_channel="rgb",
        fixed_positions={"reye": SG2_REYE_POS, "leye": SG2_LEYE_POS},
    )
    postprocess_fn = lambda x: postprocessor(x).astype("uint8")
    return postprocess_fn


def get_cropper():
    SIZE = 182
    IMG_REYE_POS = (SIZE / 3, SIZE / 3)
    IMG_LEYE_POS = (SIZE / 3, 2 * SIZE / 3)
    CROP_REYE_POS = (46, 53)
    CROP_LEYE_POS = (46, 107)
    cropper = FaceCrop(
        cropped_image_size=(160, 160),
        cropped_positions={"reye": CROP_REYE_POS, "leye": CROP_LEYE_POS},
        color_channel="rgb",
        fixed_positions={"reye": IMG_REYE_POS, "leye": IMG_LEYE_POS},
    )
    return cropper


def initialization(
    ict,
    pose_scaling,
    illumination_scaling,
    expression_scaling,
    color_variations,
    output_dir,
    task_id,
    seed,
):
    # Fix randomness
    tflib.init_tf({"rnd.np_random_seed": seed, "rnd.tf_random_seed": "auto"})

    cropper = get_cropper()
    generator = StyleGAN2Generator(randomize_noise=False, batch_size=4)
    image_postprocessor = get_postprocessing_fn()

    image_dir = os.path.join(output_dir, "image")
    ref_metadata_dir = os.path.join(output_dir, "metadata", "identities")
    aug_metadata_dir = os.path.join(
        output_dir, "metadata", "samples.{}".format(task_id)
    )

    for folder in [image_dir, ref_metadata_dir, aug_metadata_dir]:
        if not os.path.exists(folder):
            os.makedirs(folder)

    covariates_scaling = {
        "pose": pose_scaling,
        "illumination": illumination_scaling,
        "expression": expression_scaling,
    }

    db_generator = DBGenerator(
        generator=generator,
        image_postprocessor=image_postprocessor,
        cropper=cropper,
        extractor=extractor,
        ict=ict,
        covariates_scaling=covariates_scaling,
        color_variations=color_variations,
        image_dir=image_dir,
        references_metadata_dir=ref_metadata_dir,
        augmentations_metadata_dir=aug_metadata_dir,
        seed=seed,
    )

    return db_generator


@click.command(
    cls=ConfigCommand,
    entry_point_group='generation_config',
    help="Generate a synthetic database using semantic augmentation in the latent space.",
)
@click.option(
    "--num-identities",
    "-n",
    required=True,
    type=int,
    help="Number of identities in the database",
    cls=ResourceOption,
)
@click.option(
    "--ict",
    "-i",
    type=float,
    required=True,
    help="Minimum interclass distance between distinct identities",
    cls=ResourceOption,
)
@click.option(
    "--pose-scaling",
    "-ps",
    type=float,
    help="Strength of the pose augmentation",
    cls=ResourceOption,
)
@click.option(
    "--illumination-scaling",
    "-is",
    type=float,
    help="Strength of the illumination augmentation",
    cls=ResourceOption,
)
@click.option(
    "--expression-scaling",
    "-es",
    type=float,
    help="Strength of the expression augmentation",
    cls=ResourceOption,
)
@click.option(
    "--color-variations",
    "-c",
    type=int,
    help="Number of color variations per image",
    cls=ResourceOption,
)
@click.option(
    "--output-dir",
    "-o",
    type=str,
    required=True,
    default=rc['bob.synface.synthetic_datasets'],
    help="Root of the output directory tree",
    cls=ResourceOption,
)
@click.option(
    "--seed",
    "-s",
    type=int,
    help="Random seed. Fix for reproducibility.",
    cls=ResourceOption,
)
@click.option(
    "--task",
    "-t",
    type=click.Choice(["full", "references", "augmentations"]),
    help="Subtask to execute",
    cls=ResourceOption,
)
def db_gen(
    num_identities,
    ict,
    output_dir,
    seed,
    task,
    pose_scaling=1.0,
    illumination_scaling=1.0,
    expression_scaling=1.0,
    color_variations=0,
    **kwargs
):
    current_task, num_tasks = get_task()
    db_generator = initialization(
        ict=ict,
        pose_scaling=pose_scaling,
        illumination_scaling=illumination_scaling,
        expression_scaling=expression_scaling,
        color_variations=color_variations,
        output_dir=output_dir,
        task_id=current_task,
        seed=seed,
    )

    identities = list(range(num_identities))[current_task::num_tasks]

    if task == "references":
        db_generator.create_references(identities)
    elif task == "augmentations":
        db_generator.augment_identities(identities)
    else:
        db_generator.create_database(identities)


if __name__ == "__main__":
    db_gen()
