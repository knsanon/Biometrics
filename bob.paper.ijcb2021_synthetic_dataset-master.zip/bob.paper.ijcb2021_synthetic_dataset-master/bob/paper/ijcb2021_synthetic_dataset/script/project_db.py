# Copyright (c) 2021, Idiap Research Institute. All rights reserved.
#
# This work is made available under a custom license, Non-Commercial Research and Educational Use Only 
# To view a copy of this license, visit
# https://gitlab.idiap.ch/bob/bob.paper.ijcb2021_synthetic_dataset/-/blob/master/LICENSE.txt
import os
import click

import bob.io.base
import bob.io.image
from bob.extension import rc

from ..utils import get_task, fix_randomness
from ..stylegan2.preprocessor import FFHQCropper
from ..stylegan2.generator import StyleGAN2Generator
from ..stylegan2.projector import Projector

from bob.extension.scripts.click_helper import (
    ResourceOption,
    ConfigCommand,
)

from ..utils import fix_randomness

CROP_DIR = "img_aligned"
PROJ_DIR = "projected"
LAT_DIR = "w_latents"


def is_processed(f, output_dir):
    return os.path.exists(f.make_path(os.path.join(output_dir, LAT_DIR), ".h5"))


@click.command(
    cls=ConfigCommand,
    entry_point_group='projection_config',
    help="Project a bob.bio.base.database.BioDatabase into the StyleGAN2 latent space.",
)
@click.option(
    "--database",
    "-d",
    entry_point_group='projected_db',
    required=True,
    cls=ResourceOption,
    help="Which bob.bio.database to project (available : 'multipie_U', 'multipie_E', 'multipie_P')"
)
@click.option(
    "--output-dir",
    "-o",
    default=rc['bob.synface.multipie_projections'], 
    cls=ResourceOption,
    help="Root directory of the output files",
)
@click.option(
    "--num_steps",
    "-n",
    type=int,
    default=1000,
    cls=ResourceOption,
    help="Number of steps during projection. Lower values will decrease total projection runtime but could also lead to lesser quality latents. Keeping the default is the safest option.",
)
@click.option(
    "--group",
    "-g",
    default="world",
    cls=ResourceOption,
    help="Either `world`, `dev` or `eval`. By default, project the `world` set",
)
@click.option(
    "--checkpoint",
    "-c",
    is_flag=True,
    cls=ResourceOption,
    help="Activate flag to checkpoint cropped faces and projected faces",
)
@click.option(
    "--force",
    "-f",
    is_flag=True,
    cls=ResourceOption,
    help="`Activate flag to overwrite computed latent if they already exist",
)
@click.option(
    "--seed",
    "-s",
    type=int,
    cls=ResourceOption,
    help="Seed to control stochasticity during projection.",
)
def project(
    database,
    output_dir,
    group="world",
    num_steps=1000,
    checkpoint=False,
    force=False,
    seed=None,
    **kwargs
):
    failure_file_path = os.path.join(output_dir, "failure.dat")
    fix_randomness(seed=seed)

    cropper = FFHQCropper()
    generator = StyleGAN2Generator()
    projector = Projector(num_steps=num_steps)
    projector.set_network(generator.network)

    task_id, num_tasks = get_task()

    if group == "world":
        files = database.training_files()
    else:
        files = database.test_files(group)

    if not force:
        files = [f for f in files if not is_processed(f, output_dir)]

        if os.path.exists(failure_file_path):
            with open(failure_file_path, "r") as failure_file:
                fail_cases = [item.rstrip() for item in failure_file]

            files = [f for f in files if f.path not in fail_cases]

    subfiles = files[task_id :: num_tasks]
    print("{} files remaining. Handling {} of them".format(len(files), len(subfiles)))

    for i, f in enumerate(subfiles):
        print("{} : {}".format(i, f))
        image = f.load(database.original_directory, database.original_extension)

        try:
            cropped = cropper(image)
        except:
            with open(failure_file_path, "a") as failure_file:
                failure_file.write(f.path + "\n")
            print("Failure to crop {} !".format(f))
            continue

        if checkpoint:
            bob.io.base.save(
                cropped,
                f.make_path(os.path.join(output_dir, CROP_DIR), ".png"),
                create_directories=True,
            )

        projected = projector(cropped)

        if checkpoint:
            bob.io.base.save(
                projected.image,
                f.make_path(os.path.join(output_dir, PROJ_DIR), ".png"),
                create_directories=True,
            )

        bob.io.base.save(
            projected.w_latent,
            f.make_path(os.path.join(output_dir, LAT_DIR), ".h5"),
            create_directories=True,
        )


if __name__ == "__main__":
    project()
