# Copyright (c) 2021, Idiap Research Institute. All rights reserved.
#
# This work is made available under a custom license, Non-Commercial Research and Educational Use Only 
# To view a copy of this license, visit
# https://gitlab.idiap.ch/bob/bob.paper.ijcb2021_synthetic_dataset/-/blob/master/LICENSE.txt
import os
from bob.extension import rc
import click
from bob.extension.scripts.click_helper import (
    ResourceOption,
    ConfigCommand,
)
import pickle
from ..latent import analysis

@click.command(
    cls=ConfigCommand,
    help="Compute and save latent directions starting from precomputed latent projections of MultiPIE",
)
@click.option(
    "--projections_dir",
    "-i",
    type=str,
    default=rc['bob.synface.multipie_projections'],
    help="Root of directory containing Multipie projections",
    cls=ResourceOption,
)
@click.option(
    "--output_path",
    "-o",
    type=str,
    default=rc['bob.synface.latent_directions'],
    help="Path where to store the latent directions (pickle file)",
    cls=ResourceOption,
)
@click.option(
    "--force",
    "-f",
    is_flag=True,
    cls=ResourceOption,
    help="`Activate flag to overwrite computed directions if the file already exist",
)
@click.option(
    "--seed",
    "-s",
    type=int,
    cls=ResourceOption,
    help="Seed to control stochasticity during the SVM fitting.",
)
def compute_latents(projections_dir=rc['bob.synface.multipie_projections'],
                    output_path=rc['bob.synface.latent_directions'],
                    force=False,
                    seed=None,
                    **kwargs):

    if (not os.path.exists(output_path)) or force:
        out = {}
        for covariate in ['illumination','expression','pose']:
            print('Analyzing {} covariate ...'.format(covariate))
            print('    Loading projected latents ...')
            df = analysis.load_latents(covariate)
            print('    SVM fitting ...')
            result = analysis.covariate_analysis(covariate, df, seed)
            out[covariate] = result

        with open(output_path, 'wb') as f:
            pickle.dump(out, f)
    
    else:
        print('Computed directions are already found under {}. Use the --force flag to overwrite them.'.format(output_path))

if __name__ == "__main__":
    compute_latents()