import os
from bob.extension import rc
from bob.bio.base.database import CSVToSampleLoaderBiometrics, CSVDataset
from bob.bio.face.database.sample_loaders import MultiposeAnnotations
import bob.io.image
from sklearn.pipeline import make_pipeline

# For a fair comparison with the equivalent Syn-Multi-PIE protocol,
# we don't use the P protocol (which use pose up to +/- 90%)
# but a custom P center that uses only cameras between +/- 45°
# (the same cameras that are used during projection to find the pose editing directions)
#
# Kept cameras : ["08_0", "13_0", "14_0", "05_1", "05_0", "04_1", "19_0"]

def get_database():
    csv_dir = os.path.join(rc['bob.paper.ijcb2021_synthetic_dataset.path'],
                           'bob/paper/ijcb2021_synthetic_dataset/config/database/multipie/protocols')
                                        
    database = CSVDataset(dataset_protocol_path=csv_dir,
                          protocol_name='P_center',
                          csv_to_sample_loader=make_pipeline(
                            CSVToSampleLoaderBiometrics(
                                data_loader=bob.io.image.load,
                                dataset_original_directory=rc["bob.db.multipie.directory"]
                                if rc["bob.db.multipie.directory"]
                                else "",
                                extension=".png",
                                ),
                            MultiposeAnnotations(),
                          ),
    )

    database.fixed_positions = None
    database.annotation_type = ["eyes-center", "left-profile", "right-profile"]

    return database

database = get_database()