from bob.bio.face.database.multipie import MultipieDatabase

database = MultipieDatabase(protocol='E')