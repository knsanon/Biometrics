import os
from bob.extension import rc
import bob.io.image
from bob.bio.base.database import CSVToSampleLoaderBiometrics, CSVDataset

def get_database(protocol):

    image_dir = os.path.join(rc['bob.synface.synthetic_datasets'], 'synmultipie', 'image')
    csv_dir = os.path.join(rc['bob.paper.ijcb2021_synthetic_dataset.path'],
                           'bob/paper/ijcb2021_synthetic_dataset/config/database/synmultipie/protocols')

    sample_loader = CSVToSampleLoaderBiometrics(data_loader=bob.io.image.load,
                                      dataset_original_directory = image_dir,
                                      extension='.png')
                                      
    database = CSVDataset(dataset_protocol_path=csv_dir,
                          protocol_name=protocol,
                          csv_to_sample_loader=sample_loader)

    SIZE = 182
    FIXED_RIGHT_EYE_POS = (SIZE/3, SIZE/3)
    FIXED_LEFT_EYE_POS = (SIZE/3, 2*SIZE/3)

    database.fixed_positions = {"leye": FIXED_LEFT_EYE_POS, "reye": FIXED_RIGHT_EYE_POS}
    database.annotation_type = 'eyes-center'
    return database

database = get_database('U')