from bob.extension import rc
import os

ict=0.1
seed=0
pose_scaling=1
illumination_scaling=1
expression_scaling=1
color_variations=0
num_identities=64+65
output_dir = os.path.join(rc['bob.synface.synthetic_datasets'], 'synmultipie')