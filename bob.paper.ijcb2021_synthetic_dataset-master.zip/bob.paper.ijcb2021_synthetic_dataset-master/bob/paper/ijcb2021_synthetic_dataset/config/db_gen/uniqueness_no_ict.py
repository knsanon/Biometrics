import os
from bob.extension import rc
ict=0.0
seed=0
task='references'
num_identities=11000
output_dir = os.path.join(rc['bob.synface.synthetic_datasets'], 'uniqueness_no_ict')