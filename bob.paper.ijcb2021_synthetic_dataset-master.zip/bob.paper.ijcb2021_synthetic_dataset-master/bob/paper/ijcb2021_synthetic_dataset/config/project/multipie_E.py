import os
from bob.extension import rc
from bob.bio.base.database import FileListBioDatabase


database = FileListBioDatabase(
    filelists_directory=os.path.join(rc['bob.paper.ijcb2021_synthetic_dataset.path'],
                                     'bob/paper/ijcb2021_synthetic_dataset/config/project/protocols'),
    name='multipie',
    protocol='E_lit',
    original_directory=rc['bob.db.multipie.directory'],
    original_extension='.png'
)

seed=0
num_steps=1000
