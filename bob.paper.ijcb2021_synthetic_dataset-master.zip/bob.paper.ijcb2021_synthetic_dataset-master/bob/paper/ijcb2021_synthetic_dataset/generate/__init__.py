# Copyright (c) 2021, Idiap Research Institute. All rights reserved.
#
# This work is made available under a custom license, Non-Commercial Research and Educational Use Only 
# To view a copy of this license, visit
# https://gitlab.idiap.ch/bob/bob.paper.ijcb2021_synthetic_dataset/-/blob/master/LICENSE.txt
import numpy as np
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

# General utility functions
def db_gen_runtime_estimate(embedding_time, 
                            num_identities, 
                            samples_per_identity,
                            average_new_identity_rejects,
                            average_new_sample_rejects):
    """
    Estimate the total runtime of a database generation given the provided requirements and specifications.
    Inputs:
    `embedding_time` : time to generate embedding from latent vector
    `num_identities` : number of different identites to generate
    `samples_per_identity` : required number of samples per identity
    `average_new_identity_rejects` : expected number of rejects for new identities (when to close from preexisting one)
    `average_new_sample_rejects` : expected number of rejects for new samples (when to far from target identity)

    Returns:
    estimated total runtime in the same units as the input `embedding_time`
    """

    total = 0.0
    total += (average_new_identity_rejects + 1) * num_identities * embedding_time
    total += (average_new_sample_rejects + 1) * (samples_per_identity - 1) * num_identities * embedding_time
    return total
