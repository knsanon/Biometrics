# Copyright (c) 2021, Idiap Research Institute. All rights reserved.
#
# This work is made available under a custom license, Non-Commercial Research and Educational Use Only 
# To view a copy of this license, visit
# https://gitlab.idiap.ch/bob/bob.paper.ijcb2021_synthetic_dataset/-/blob/master/LICENSE.txt
import os
import numpy as np
from scipy.spatial.distance import cosine as cosine_dist
import bob.io.image
import bob.io.base

class Face(object):
    def __init__(self, 
                 z_latent,
                 w_latent,
                 image,
                 embedding,
                 identity,
                 sample,
                 preprocessed=None):
        self.z_latent = z_latent
        self.w_latent = w_latent
        self.image = image
        self.preprocessed = preprocessed
        self.embedding = embedding

        self.identity = identity
        self.sample = sample

    def show(self):
        bob.io.image.imshow(self.image)

    def show_preprocessed(self):
        bob.io.image.imshow(self.preprocessed)
    
    @staticmethod
    def distance(face1, face2, modules=None):
        """
        Compute the identity-distance between two latent vectors from StyleGAN2's 
        latent space. 
        """
        unwrap = lambda x : x.embedding if isinstance(x, Face) else x
        return 0.5*np.linalg.norm(unwrap(face1) - unwrap(face2))**2

    @staticmethod
    def get_all_distances(face_pairs):
        """
        From a list of size n of 2-tuples of Faces with embeddings, compute distances between all pairs
        and returns a list of length n containing those distances
        """
        return [Face.distance(pair[0], pair[1]) for pair in face_pairs]
    
    @staticmethod
    def _build_unique_id(identity, sample):
        return str(identity) + '_' + str(sample)

    def get_unique_id(self):
        return Face._build_unique_id(self.identity, self.sample)

    @staticmethod
    def get_path(identity, sample, content, extension='', output_dir=None):
        if output_dir is not None:
            return os.path.join(output_dir, content, str(identity), Face._build_unique_id(identity, sample) + extension) 
        else:
            return os.path.join(content, str(identity), Face._build_unique_id(identity, sample) + extension)

    def save(self, root_dir,
                   h5_file,
                   save_preprocessed=False):
        
        if self.z_latent is not None:
            h5_file.create_dataset(Face.get_path(self.identity, self.sample, 'z_latent'), data=self.z_latent)
        h5_file.create_dataset(Face.get_path(self.identity, self.sample, 'w_latent'), data=self.w_latent)

        bob.io.base.save(self.image, Face.get_path(self.identity, self.sample, '', '.png', root_dir), create_directories=True)

        if save_preprocessed and self.preprocessed is not None:
            h5_file.create_dataset(Face.get_path(self.identity, self.sample, 'preprocessed'), data=self.preprocessed)
        h5_file.create_dataset(Face.get_path(self.identity, self.sample, 'embedding'), data=self.embedding)
        h5_file.flush()

    @classmethod
    def load(cls, root_dir, h5_file, identity, sample):
        z_latent_path = Face.get_path(identity, sample, 'z_latent')
        if z_latent_path in h5_file:
            z_latent = h5_file[z_latent_path][:]
        else:
            z_latent = None
            
        w_latent = h5_file[Face.get_path(identity, sample, 'w_latent')][:]
        image = bob.io.base.load(Face.get_path(identity, sample, '', '.png', root_dir))

        preprocessed_path = Face.get_path(identity, sample, 'preprocessed')
        if preprocessed_path in h5_file:
            preprocessed = h5_file[preprocessed_path][:]
        else:
            preprocessed = None
        embedding = h5_file[Face.get_path(identity, sample, 'embedding')][:]

        face = cls(z_latent=z_latent,
                   w_latent=w_latent,
                   image=image,
                   embedding=embedding,
                   identity=identity,
                   sample=sample,
                   preprocessed=preprocessed)

        return face


        



    