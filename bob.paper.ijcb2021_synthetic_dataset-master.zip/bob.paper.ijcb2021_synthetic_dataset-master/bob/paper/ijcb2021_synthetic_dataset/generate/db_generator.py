# Copyright (c) 2021, Idiap Research Institute. All rights reserved.
#
# This work is made available under a custom license, Non-Commercial Research and Educational Use Only 
# To view a copy of this license, visit
# https://gitlab.idiap.ch/bob/bob.paper.ijcb2021_synthetic_dataset/-/blob/master/LICENSE.txt
import os
import h5py
import numpy as np
import time
import pickle as pkl
from bob.extension import rc
from .face_wrapper import Face
from ..latent import editing
from scipy.spatial.distance import cdist

COVARIATES = ["expression", "pose", "illumination"]
MAX_FILES_PER_FOLDER = 1000


class DBGenerator(object):
    def __init__(
        self,
        generator,
        image_postprocessor,
        cropper,
        extractor,
        ict,
        covariates_scaling,
        color_variations,
        image_dir,
        references_metadata_dir,
        augmentations_metadata_dir,
        seed,
        covariates_analysis_path=rc["bob.synface.latent_directions"],
    ):
        """[summary]

        Parameters
        ----------
        generator : :synthface.generate.stylegan2_generator.StyleGAN2Generator:
            The core StyleGAN2 generator used for face image generation
        image_postprocessor : callable
            Function to apply on the generated images before saving & embedding
            computation. Typically : downscaling/cropping from 1024x1024 to lower resolution.
        cropper : bob.bio.face.Preprocessor
            Cropper stage of the embedding computation
        extractor : bob.bio.face.Extractor
            Extractor stage of the embedding computation
        ict : float
            Inter-class threshold requirement. During generation of the references for each identity in the
            database, the generator will ensure that each new identity has is at least at a distance `ict` from
            the previous identities, in the embedding space.
        covariates_scaling : dict
            Scaling factors for each type of semantic augmentation. Example:
            ```
            covariates_scaling = {
                "pose" : 3/4,
                "illumination": 5/4,
                "expression": 1.0
            }
            ```
        color_variations : int
            Number of color variations of each image to generate.
            If set to 0, then no color variation is applied (only the semantic augmentations are computed)-
        image_dir : str
            Root directory where to store the images.
        references_metadata_dir : str
            Path to the folder where is stored the metadata on the references (latents, embeddings, statistics)
        augmentations_metadata_dir : str
            Path to the folder where is stored the metadata on the augmented faces (latents, embeddings, statistics)
        seed : int
            Seed of the random generator for reproducibility
        covariates_analysis_path: str
            Path to pickled covariaties analysis results (that contains the latent directions)
        """

        self.generator = generator
        self.image_postprocessor = image_postprocessor
        self.cropper = cropper
        self.extractor = extractor
        self.seed = seed
        with open(covariates_analysis_path, "rb") as f:
            self.covariates_analysis = pkl.load(f)

        self.ict = ict
        self.covariates_scaling = covariates_scaling
        self.color_variations = color_variations
        self.image_dir = image_dir
        self.references_metadata_dir = references_metadata_dir
        self.augmentations_metadata_dir = augmentations_metadata_dir
        self.references_hdf5_path = os.path.join(
            self.references_metadata_dir, "representations.h5"
        )
        self.augmentations_hdf5_path = os.path.join(
            self.augmentations_metadata_dir, "representations.h5"
        )

    def _get_subdir(self, identity):
        return "{:05}".format(identity // MAX_FILES_PER_FOLDER)

    def get_embedding(self, img):
        return self.extractor(self.cropper(img))

    def get_color_augmented_faces(self, identity, w_augmented, labels):
        """ Generate faces from w-latents using style-mixing to add some color variation.
        The identity specific latents are used for coarse resolution inputs (4x4 to 64x64) of the synthesis network, 
        while another randomly generated latent is used for fine resolutions (128x128 to 1024x1024).

        Parameters
        ----------
        identity : int
            Tag for the identity that is currently processed.
        w_augmented : np.array of shape (num_latents, latent_dim)
            Base w-latents for the current identity (including the semantically augmented latents and optionally the reference latent)
        labels : iterable of str
            Sample tag for each latent in w_augmented

        Returns
        -------
        List of all Faces obtained after computing the synthetic image and associated face embeddings.
        """

        # Compute resulting image with style mixing
        # By choice, the style_mixing_depth and truncation_psi are hardcoded as carelessly chosen values
        # can lead the generated images to not all match to the same identity.

        images, all_base_latents, _ = self.generator.run_with_style_mixing_augmentation(
            w_augmented,
            num_variations=self.color_variations,
            style_mixing_depth=10,
            truncation_psi=0.85,
            return_w_latents=True,
        )
        images = [self.image_postprocessor(img) for img in images]

        # Update labels to differentiate variations
        labels = [
            ["{}_var_{}".format(label, variation) for label in labels]
            for variation in range(self.color_variations)
        ]
        labels = sum(labels, [])

        # Extract embeddings
        embeddings = [self.get_embedding(img) for img in images]

        # Encapsulate as faces
        faces = [
            Face(
                z_latent=None,
                w_latent=w,
                image=img,
                embedding=embedding,
                identity=identity,
                sample=label,
            )
            for w, img, embedding, label in zip(
                all_base_latents, images, embeddings, labels
            )
        ]
        return faces

    def get_faces(self, identity, w_augmented, labels):
        """
        Generate faces from w_latents, in particular including the computation of face embeddings.

        Parameters
        ----------
        identity : int
            Tag for the identity that is currently processed.
        w_augmented : np.array of shape (num_latents, latent_dim)
            Base w-latents for the current identity (including the semantically augmented latents and optionally the reference latent)
        labels : iterable of str
            Sample tag for each latent in w_augmented

        Returns
        -------
        List of all Faces obtained after computing the synthetic image and associated face embeddings.
        """
        # Compute images and embeddings
        images = self.generator.run_from_W(w_augmented)
        images = [self.image_postprocessor(img) for img in images]
        embeddings = [self.get_embedding(img) for img in images]

        # Encapsulate as faces
        faces = [
            Face(
                z_latent=None,
                w_latent=w,
                image=img,
                embedding=embedding,
                identity=identity,
                sample=label,
            )
            for w, img, embedding, label in zip(w_augmented, images, embeddings, labels)
        ]
        return faces

    def create_reference(self, identity, compared_embeddings):
        """ Create the reference Face for the required identity by randomly sampling a new latent vector,
        ans computing the face image as well as the face embedding.
        Embeddings of preexisting identities must be provided in order to apply
        an inter-class distance constraint.

        Parameters
        ----------
        identity : int
            Tag of the currently generated identity
        compared_embeddings : iterable of np.arrays
            Embeddings of all preexisting identities in the database (embeddings have dimensionality (128, )).

        Returns
        -------
        :synthface.generate.face_wrapper.Face:
    
        """

        # For reproducibility : random generator is reseeded for each identity
        # using a composite seed that depends on the generator seed, and on the
        # identity tag itself.
        np.random.seed([self.seed, identity, 0])

        accepted = False
        num_candidates = 0
        # Generate candidates until the ICT requirement is satistfied
        while not accepted:
            num_candidates += 1
            # Sample a new identity from the Z space
            ref_z = np.random.randn(1, self.generator.latent_dim)
            _, ref_w = self.generator.run_from_Z(ref_z, return_w_latents=True)

            # Neutralize it (make it frontal view, frontal lightning, neutral expression)
            ref_w = editing.latent_neutralisation(ref_w, self.covariates_analysis)

            # Compute the image and embeddings
            raw_images = self.generator.run_from_W(ref_w)
            ref_img = self.image_postprocessor(raw_images[0])
            ref_embedding = self.get_embedding(ref_img)

            # Compare the new embedding to previous embeddings, and accept the candidate only
            # if the ICT constraint is satisfied
            if len(compared_embeddings) > 0:
                distances = (
                    0.5
                    * cdist([ref_embedding], compared_embeddings, metric="sqeuclidean")[
                        0
                    ]
                )
                accepted = np.all(distances >= self.ict)
            else:
                accepted = True

        # Encapsulate as a Face
        ref_face = Face(
            z_latent=ref_z,
            w_latent=ref_w,
            image=ref_img,
            embedding=ref_embedding,
            identity=identity,
            sample="reference",
        )
        return ref_face, num_candidates

    def augment_identity(self, reference_face):
        """ Generate all semantic augmentations for the provided reference.

        Parameters
        ----------
        reference_face : :synthface.generate.face_wrapper.Face:
            Reference Face

        Returns
        -------
        list of :synthface.generate.face_wrapper.Faces:
            Faces for each semantic augmentations of the reference
        """
        # Compute semantic augmentations
        w_augmented, labels = editing.latent_augmentation(
            reference_face.w_latent, self.covariates_analysis, self.covariates_scaling
        )

        # Optionally, also add color variation
        if self.color_variations == 0:
            # Exclude the first latent (which is the latent from the reference), as it already is in the database
            faces = self.get_faces(reference_face.identity, w_augmented[1:], labels[1:])
        else:
            faces = self.get_color_augmented_faces(
                reference_face.identity, w_augmented, labels
            )

        return faces

    def save_faces(self, faces, h5_file):
        """ Save a list of faces

        Parameters
        ----------
        faces :
            List of Faces to save
        h5_file : str
            Path to the hdf5 file where the Face's representations (latents, embeddings) must be stored
        """
        with h5py.File(h5_file) as f:
            for face in faces:
                face.save(
                    os.path.join(self.image_dir, self._get_subdir(face.identity)), f
                )

    def load_reference(self, identity):
        """ Load a precomputed reference Face from the filesystem

        Parameters
        ----------
        identity : int
            Tag for the identity of the reference to load

        Returns
        -------
        :synthface.generate.face_wrapper.Face: 
            Face of the reference

        Raises
        ------
        RuntimeError
            When the reference cannot be found if the filesytem (either if the HDF5 file does not exists,
            or if it exists but does not contain this identity tag)
        """
        try:
            with h5py.File(self.references_hdf5_path, "r") as f:
                reference = Face.load(
                    os.path.join(self.image_dir, self._get_subdir(identity)),
                    f,
                    identity,
                    "reference",
                )
        except:
            raise RuntimeError(
                "Reference for identity {} is not yet generated and thus cannot be restored".format(
                    identity
                )
            )

        return reference

    def list_references(self):
        """
        Run through the filesystem to list all identities whose reference Face
        has already been computed.

        Returns
        -------
        List of int
            List of tags of all identities whose reference already exists
        """
        if os.path.exists(self.references_hdf5_path):
            with h5py.File(self.references_hdf5_path, "r") as f:
                return [int(k) for k in f["embedding"].keys()]
        else:
            return []

    def create_database(self, identities):
        """ Create a full database (reference + augmentations) for the provided identity tags

        Parameters
        ----------
        identities : List of int
            List of unique tags for each identity that must be created
        """
        self.create_references(identities)
        self.augment_identities(identities)

    def create_references(self, identities):
        """ Create all references for the provided identity tags

        Parameters
        ----------
        identities : List of int
            List of unique tags for each identity that must be created
        """
        print("Creating references...")
        # List preexisting identities and load their embeddings
        previous_identities = self.list_references()
        compared_embeddings = [
            self.load_reference(identity).embedding for identity in previous_identities
        ]

        # Don't regenerate preexisting identities
        identities = set(identities).difference(set(previous_identities))

        num_identities = len(identities)
        for idx, identity in enumerate(identities):
            print("Identity {} ({}/{})".format(identity, idx + 1, num_identities))

            # Create reference
            start_time = time.time()
            ref_face, num_candidates = self.create_reference(
                identity, compared_embeddings
            )
            runtime = time.time() - start_time

            # Store stats
            with open(
                os.path.join(self.references_metadata_dir, "stats.dat"), "a"
            ) as f:
                f.write("{} {:.2f} {}\n".format(identity, runtime, num_candidates))

            # Store face
            self.save_faces([ref_face], self.references_hdf5_path)
            compared_embeddings.append(ref_face.embedding)

    def augment_identities(self, identities):
        """ Create all augmentations for the provided identity tags.
        This method assumes the references for those identities have already been 
        created.

        Parameters
        ----------
        identities : List of str or int
            List of unique tags for each identity that must be created
        """
        print("Augmenting identities...")
        num_identities = len(identities)
        for idx, identity in enumerate(identities):
            print("Identity {} ({}/{})".format(identity, idx + 1, num_identities))
            ref_face = self.load_reference(identity)

            # Augment identity
            start_time = time.time()
            faces = self.augment_identity(ref_face)
            runtime = time.time() - start_time

            # Store stats
            with open(
                os.path.join(self.augmentations_metadata_dir, "stats.dat"), "a"
            ) as f:
                f.write("{} {:.2f}\n".format(identity, runtime))

            self.save_faces(faces, self.augmentations_hdf5_path)
