
# Copyright (c) 2021, Idiap Research Institute. All rights reserved.
#
# This work is made available under a custom license, Non-Commercial Research and Educational Use Only 
# To view a copy of this license, visit
# https://gitlab.idiap.ch/bob/bob.paper.ijcb2021_synthetic_dataset/-/blob/master/LICENSE.txt
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)
import numpy as np
import os

def fix_randomness(seed=None):
    from ..stylegan2.dnnlib import tflib
    config = {'rnd.np_random_seed': seed,
            'rnd.tf_random_seed': 'auto'}
    tflib.init_tf(config)

def adjust_dynamic_range(image, target_range, dtype):
    minval = np.min(image)
    maxval = np.max(image)
    return ((target_range[0]*(maxval - image) + target_range[1]*(image-minval))/(maxval - minval)).astype(dtype)

def normalize(v):
    """
    Return a normlaized version of the input vector
    """
    return v/np.linalg.norm(v)

def lerp(p0, p1, n, start=0.0, end=1.0):
    """
    Linear interpolation between two points
    Inputs:
        p0, p1: Rank-1 numpy vectors with same dimension D
        n: int, total number of points to return
        start, end : control the range of the interpolation, i.e. the range of interpolation parameter t.
                    Interpolated points are computed as (1-t)*p0 + t*p1 where t can takes linearly spaced values
                    in the range [start, end] (included).

    Returns:
        p : Numpy vector of shape (n, D) containing all interpolated points
    """
    t = np.linspace(start, end, n)[:, np.newaxis]
    p = (1-t) * p0[np.newaxis, :] + t * p1[np.newaxis, :]
    return p

def logerp(p0, p1, n, start=-10.0, end=0.0):
    """
    Logarithmic interpolation between two points
    Inputs:
        p0, p1: Rank-1 numpy vectors with same dimension D
        n: int, total number of points to return
        start, end : control the range of the interpolation, i.e. the range of interpolation parameter t.
                    Interpolated points are computed as (1-t)*p0 + t*p1 where t can takes logarithmically spaced values
                    in the range [10^start, 10^end] (included).

    Returns:
        p : Numpy vector of shape (n, D) containing all interpolated points
    """
    t = np.logspace(start, end, n)[:, np.newaxis]
    p = (1-t) * p0[np.newaxis, :] + t * p1[np.newaxis, :]
    return p

def rand_cos_dist(v, cos_dist):
    """
    From an input vector `v` and a target cosine distance `cos_dist`,
    returns a random unit vector w with same dimension as `v` such that
    cosine_distance(`v`, `w`) = `cos_dist`.
    """
    costheta = 1-cos_dist
    # Form the unit vector parallel to v:
    u = v / np.linalg.norm(v)
    latent_dim = v.shape[0]

    # Pick a random vector:
    r = np.random.randn(latent_dim)

    # Form a vector perpendicular to v:
    uperp = r - r.dot(u)*u

    # Make it a unit vector:
    uperp = uperp / np.linalg.norm(uperp)

    # w is the linear combination of u and uperp with coefficients costheta
    # and sin(theta) = sqrt(1 - costheta**2), respectively:
    w = costheta*u + np.sqrt(1 - costheta**2)*uperp

    return w

def get_task():

    if 'SGE_TASK_ID' in os.environ and os.environ['SGE_TASK_ID'] != 'undefined':
        current_task = int(os.environ['SGE_TASK_ID']) - 1
        num_tasks = int(os.environ['SGE_TASK_LAST'])
    else:
        current_task = 0
        num_tasks = 1

    return current_task, num_tasks
