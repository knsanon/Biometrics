
# Copyright (c) 2021, Idiap Research Institute. All rights reserved.
#
# This work is made available under a custom license, Non-Commercial Research and Educational Use Only 
# To view a copy of this license, visit
# https://gitlab.idiap.ch/bob/bob.paper.ijcb2021_synthetic_dataset/-/blob/master/LICENSE.txt
import os
import urllib.request
import bz2
import bob.extension
import bob.extension.download
import bob.io.base
import bob.extension.rc_config

from bob.extension import rc

DLIB_LMD_PATH = rc['sg2_morph.dlib_lmd_path']
SG2_PATH = rc['sg2_morph.sg2_path']
VGG16_PATH = rc['sg2_morph.vgg16_path']
FR_MODELS_PATH = rc['bob.bio.face_ongoing.models_path']

def makedirs(path):
    folder = os.path.dirname(path)
    if not os.path.exists(folder):
        os.makedirs(folder)

def download_dlib_lmd():
    dlib_url = "http://dlib.net/files/shape_predictor_68_face_landmarks.dat.bz2"
    if not os.path.exists(DLIB_LMD_PATH):
        makedirs(DLIB_LMD_PATH)

        print('Downloading dlib face landmarks detector...')
        tmp_file, _ = urllib.request.urlretrieve(dlib_url)
        with bz2.BZ2File(tmp_file, 'rb') as src, open(DLIB_LMD_PATH, 'wb') as dst:
            dst.write(src.read())
        print("Success !")
    else:
        print('dlib landmark detector already downloaded in {}'.format(DLIB_LMD_PATH))

def download_stylegan2():
    stylegan2_url = 'http://d36zk2xti64re0.cloudfront.net/stylegan2/networks/stylegan2-ffhq-config-f.pkl'
    if not os.path.exists(SG2_PATH):
        makedirs(SG2_PATH)
        print('Downloading pretrained StyleGAN2 (FFHQ-config-f)...')
        dst_file, _ = urllib.request.urlretrieve(stylegan2_url, SG2_PATH)

        print("Success !")
    else:
        print('StyleGAN2 model already downloaded in {}'.format(SG2_PATH))

def download_vgg16():
    vgg16_url = "http://d36zk2xti64re0.cloudfront.net/stylegan1/networks/metrics/vgg16_zhang_perceptual.pkl"
    if not os.path.exists(VGG16_PATH):
        makedirs(VGG16_PATH)
        print("Downloading pretrained VGG16...")
        dst_file, _ = urllib.request.urlretrieve(vgg16_url, VGG16_PATH)
        print("Success !")
    else:
        print("VGG16 model already downloaded in {}".format(VGG16_PATH))




def get_fr_models():
    """
    Define the models to be downloaded
    """

    class Model(object):

        def __init__(self, group, model_name, url, inside_file_structure):

            module = "bob.bio.face_ongoing."
            self.group       = group
            self.model_name  = model_name
            self.url         = url
            self.config_name = module + group + "-" + model_name
            self.inside_file_structure = inside_file_structure


    # MAKE AS PARAMETERS
    branch = "master"
    base_url = "https://www.idiap.ch/software/bob/data/bob/bob.bio.face_ongoing/"
    extension = ".tar.gz"
    models = []

    groups = ["msceleb"]

    # Defining the models to be downloaded
    for g in groups:
        model_name = "inception-v2_batchnorm_rgb"
        url = os.path.join(base_url, branch, g, model_name + extension)
        inside_file_structure = os.path.join("inception-v2_batchnorm_rgb")
        models.append(Model(g, model_name, url, inside_file_structure))

    return models


def download_fr_models(destination_path=FR_MODELS_PATH, **kwargs):
    """
    Download pretrained CNN  Tensorflow 1 models that are used in the package.

    The models are the following:

       Trained with MS-Celeb:

         - inception-v2-rgb: https://gitlab.idiap.ch/bob/bob.learn.tensorflow/blob/39471f5bb2ae42cf6ef7fcc69e305d76a8b44ff9/bob/learn/tensorflow/network/InceptionResnetV2.py
         
    """
   
    models = get_fr_models()

    # Downloading
    extension = ".tar.gz"
    rc = bob.extension.rc_config._loadrc()
    for m in models:
        output_path = os.path.join(destination_path, m.group, m.model_name + extension)

        # Downloading
        model_path = os.path.join(os.path.dirname(output_path), m.inside_file_structure)
        if os.path.exists(model_path):
            print("Model {0} already exists in {1}".format(m.model_name, output_path))
        else:
            print(3, "Downloading {0} in {1}".format(m.model_name, output_path))
            bob.io.base.create_directories_safe(model_path)
            bob.extension.download.download_and_unzip([m.url], output_path)


        # Setting the path
        rc[m.config_name] = model_path
        bob.extension.rc_config._saverc(rc)

    pass



def download_models():
    download_dlib_lmd()
    download_stylegan2()
    download_vgg16()
    download_fr_models()



if __name__ == "__main__":
    download_models()
