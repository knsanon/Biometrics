# Copyright (c) 2021, Idiap Research Institute. All rights reserved.
#
# This work is made available under a custom license, Non-Commercial Research and Educational Use Only 
# To view a copy of this license, visit
# https://gitlab.idiap.ch/bob/bob.paper.ijcb2021_synthetic_dataset/-/blob/master/LICENSE.txt
import matplotlib.pyplot as plt
import bob.io.image
import numpy as np

def facegrid(face_images, nrows, ncols, figsize=None, labels=None):
    """
    Produces an image grid of size (nrows, ncols) showing each image
    contained in the input `face_images` list.
    An optional `labels` list can also be provided, in which case the `labels` will be 
    used as title for each subplot in the grid.
    """
    if figsize is None:
        figsize = (2*ncols, 2*nrows)
    if labels is None:
        labels = [None]*len(face_images)
    fig, ax = plt.subplots(nrows=nrows, ncols=ncols, squeeze=False, figsize=figsize, tight_layout=True)
    for i, (face, label) in enumerate(zip(face_images, labels)):
        currax = ax[i//ncols, i%ncols]
        if face is not None:
            currax.imshow(bob.io.image.to_matplotlib(face))
        currax.axis('off')
        if label is not None:
            currax.set_title(label)
    
    return fig, ax


