# Copyright (c) 2021, Idiap Research Institute. All rights reserved.
#
# This work is made available under a custom license, Non-Commercial Research and Educational Use Only 
# To view a copy of this license, visit
# https://gitlab.idiap.ch/bob/bob.paper.ijcb2021_synthetic_dataset/-/blob/master/LICENSE.txt
from bob.extension import rc
from bob.db.multipie import Database as Multipie
import os
import pandas as pd
from sklearn.svm import LinearSVC
from sklearn.preprocessing import LabelEncoder
import numpy as np

MAIN_DIR = rc['bob.synface.multipie_projections']
LAT_DIR = os.path.join(MAIN_DIR, "w_latents")
FAILURE_FILE = os.path.join(MAIN_DIR, "failure.dat")
MULTIPIE_DIR = rc["bob.db.multipie.directory"]

VALID_COVARIATES = ['illumination','expression','pose']

POS_TO_CAM = {
    "frontal": ["05_1"],
    "left": ["11_0", "12_0", "09_0", "08_0", "13_0", "14_0"],
    "right": ["05_0", "04_1", "19_0", "20_0", "01_0", "24_0"],
}

CAM_TO_POS = {cam: pos for pos, cam_list in POS_TO_CAM.items() for cam in cam_list}

POS_TO_FLASH = {
    "no_flash": [0],
    "left": list(range(1, 7)) + [14, 15],
    "frontal": [7, 16],
    "right": list(range(8, 14)) + [17, 18],
}

FLASH_TO_POS = {
    flash: pos for pos, flash_list in POS_TO_FLASH.items() for flash in flash_list
}

EXPRESSION_TO_RECORDING = { # Recording = SessionNumber_RecordingNumber
    'neutral': ["01_01", "02_01", "03_01", "04_01", "04_02"],
    'smile': ["01_02", "03_02"],
    'surprise': ["02_02"],
    'squint': ["02_03"],
    'disgust': ["03_03"],
    'scream': ["04_03"]
}

RECORDING_TO_EXPRESSION = {
    recording : expr for expr, recording_list in EXPRESSION_TO_RECORDING.items() for recording in recording_list
}

def filter_failure_cases(file_list):
    with open(FAILURE_FILE, "r") as f:
        failures = [item.rstrip() for item in f.readlines()]

    return [f for f in file_list if f.path not in failures]


def get_covariate(file, covariate):
    if covariate == "expression":
        recording = '_'.join(file.path.split('/')[-1].split('_')[1:3])
        return RECORDING_TO_EXPRESSION[recording]
    elif covariate == "pose":
        camera = file.path.split('/')[4]
        return CAM_TO_POS[camera]
    elif covariate == "illumination":
        shot = file.path.split('/')[-1].split('_')[-1]
        return FLASH_TO_POS[int(shot)]
    else:
        raise ValueError(
            "Unknown covariate {} not in {}".format(covariate, VALID_COVARIATES)
        )

def get_file_list(covariate, group='world'):
    if covariate == 'illumination':
        db = Multipie(original_directory=MULTIPIE_DIR)
        raw_files = db.objects(protocol='U', groups=[group])
    elif covariate == 'expression':
        from ..config.project.multipie_E import database as db 
        raw_files = db.objects(groups=[group])
    elif covariate == 'pose':
        from ..config.project.multipie_P import database as db
        raw_files = db.objects(groups=[group])
    else:
        raise ValueError('Unknown covariate {}'.format(covariate))

    return filter_failure_cases(raw_files)

def load_latents(covariate, group="world"):
    assert covariate in VALID_COVARIATES, "Unknown `covariate` {} not in {}".format(
        covariate, VALID_COVARIATES
    )
    files = get_file_list(covariate, group)
    df = pd.DataFrame()
    df["file"] = [f.path for f in files]
    df["latent"] = [f.load(LAT_DIR, ".h5") for f in files]

    df[covariate] = [get_covariate(f, covariate) for f in files]

    return df


def binary_analysis(train_df, covariate, target_labels, seed=None, **kwargs):
    train_df = train_df[train_df[covariate].isin(target_labels)]
    print(seed)
    svm = LinearSVC(fit_intercept=False, random_state=seed, **kwargs)
    train_latents = np.stack(train_df["latent"])
    train_labels = np.stack(train_df[covariate])

    # Ensure that 0 and 1 classes match the order of the target_labels
    train_labels = np.where(train_labels == target_labels[0], 0, 1)

    svm.fit(train_latents, train_labels)

    normal = svm.coef_ / np.linalg.norm(svm.coef_)

    distances = train_latents.dot(normal.T)
    negatives = distances[distances < 0]
    positives = distances[distances > 0]

    def stats(distances):
        return {
            "min": np.min(distances),
            "max": np.max(distances),
            "mean": np.mean(distances),
            "std": np.std(distances),
        }

    neg_stats = stats(negatives)
    pos_stats = stats(positives)

    return {
        "svm": svm,
        "normal": normal,
        "neg_stats": neg_stats,
        "pos_stats": pos_stats,
    }


def multiclass_analysis(train_df, covariate, neutral_label, other_labels, **kwargs):
    return {
        (neutral_label, label): binary_analysis(
            train_df,
            covariate=covariate,
            target_labels=[neutral_label, label],
            **kwargs
        )
        for label in other_labels
    }


def pose_analysis(train_df, seed=None):
    return binary_analysis(train_df, covariate="pose", target_labels=["left", "right"], seed=seed)


def illumination_analysis(train_df, seed=None):
    return binary_analysis(
        train_df, covariate="illumination", target_labels=["left", "right"], seed=seed
    )


def expression_analysis(train_df, seed=None):
    return multiclass_analysis(
        train_df,
        covariate="expression",
        neutral_label="neutral",
        other_labels=["smile", "scream", "disgust", "squint", "surprise"],
        seed=seed
    )


def covariate_analysis(covariate, train_df, seed=None):
    if covariate == "expression":
        return expression_analysis(train_df, seed)
    elif covariate == "pose":
        return pose_analysis(train_df, seed)
    elif covariate == "illumination":
        return illumination_analysis(train_df, seed)
    else:
        raise ValueError(
            "Unknown covariate {} not in {}".format(covariate, VALID_COVARIATES)
        )
