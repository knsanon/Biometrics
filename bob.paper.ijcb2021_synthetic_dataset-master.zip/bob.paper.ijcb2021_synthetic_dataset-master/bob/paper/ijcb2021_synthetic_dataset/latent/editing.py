# Copyright (c) 2021, Idiap Research Institute. All rights reserved.
#
# This work is made available under a custom license, Non-Commercial Research and Educational Use Only 
# To view a copy of this license, visit
# https://gitlab.idiap.ch/bob/bob.paper.ijcb2021_synthetic_dataset/-/blob/master/LICENSE.txt
import numpy as np

LATENT_DIM = 512


def latent_neutralisation(w, covariates_analysis):
    # Pose neutralisation : project on binary decision boundary
    pose_normal = covariates_analysis["pose"]["normal"]
    w -= w.dot(pose_normal.T) * pose_normal

    # Illumination neutralisation : project on binary decision boundary
    illumination_normal = covariates_analysis["illumination"]["normal"]
    w -= w.dot(illumination_normal.T) * illumination_normal

    # Expression neutralisation
    ### Assumption : default sampled latents are always either "neutral" or "smile"
    expression_normal = covariates_analysis["expression"][("neutral", "smile")][
        "normal"
    ]
    # 1. Cancel component
    w -= w.dot(expression_normal.T) * expression_normal
    # 2. Move towards neutral using the mean distance computed on train set
    w += (
        covariates_analysis["expression"][("neutral", "smile")]["neg_stats"]["mean"]
        * expression_normal
    )

    return w


def binary_augmentation(w, analysis, num_latents, scaling):
    neg_mean = analysis["neg_stats"]["mean"]
    pos_mean = analysis["pos_stats"]["mean"]

    extremum = max(-neg_mean, pos_mean)

    normal = analysis["normal"]
    scales = scaling * np.linspace(-extremum, extremum, num_latents)[:, None]
    return w + scales * normal, scales
    

def pose_augmentation(w, pose_analysis, num_latents, scaling=3 / 4):
    return binary_augmentation(w, pose_analysis, num_latents, scaling)


def illumination_augmentation(w, illumination_analysis, num_latents, scaling=5 / 4):
    return binary_augmentation(w, illumination_analysis, num_latents, scaling)


def expression_augmentation(w, expression_analysis, scaling=3 / 4):
    new_covariates = []
    new_latents = []
    for direction, analysis in expression_analysis.items():
        new_covariates.append(direction[1])
        normal = analysis["normal"]
        # 1. Cancel neutral component
        w_augmented = w - w.dot(normal.T) * normal
        # 2. Move towards expression using the mean distance computed on train set to ensure realistic outcome
        w_augmented += scaling * analysis["pos_stats"]["mean"] * normal
        new_latents.append(w_augmented)

    return np.concatenate(new_latents), np.stack(new_covariates)


def latent_augmentation(w, covariates_analysis, covariates_scaling):
    # Pose augmentation
    w_pose, pose_labels = pose_augmentation(
        w,
        covariates_analysis["pose"],
        num_latents=6,
        scaling=covariates_scaling["pose"],
    )
    pose_labels = ["pose_{}".format(item) for item in range(len(pose_labels))]

    # Illumination augmentation
    w_illumination, illumination_labels = illumination_augmentation(
        w,
        covariates_analysis["illumination"],
        num_latents=6,
        scaling=covariates_scaling["illumination"],
    )
    illumination_labels = [
        "illumination_{}".format(item) for item in range(len(illumination_labels))
    ]

    # Expression augmentation
    w_expression, expression_labels = expression_augmentation(
        w, covariates_analysis["expression"], scaling=covariates_scaling["expression"]
    )
    expression_labels = expression_labels.flatten().tolist()

    latents = np.concatenate([w, w_pose, w_illumination, w_expression])
    labels = ["original"] + pose_labels + illumination_labels + expression_labels

    return latents, labels
